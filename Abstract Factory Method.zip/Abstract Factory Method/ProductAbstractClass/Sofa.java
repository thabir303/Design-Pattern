public abstract class Sofa {
    public abstract void printSofa();
    
}