public abstract class Chair {
    public abstract void printChair();
}