public abstract class CoffeTable {
    public abstract void printCoffeTable();
    
}