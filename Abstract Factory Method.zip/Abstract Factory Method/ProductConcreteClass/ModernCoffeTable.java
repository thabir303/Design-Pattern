public class ModernCoffeTable extends CoffeTable {
    public void printCoffeTable(){
        System.out.println("This is a Modern Coffe Table");
    }
}
