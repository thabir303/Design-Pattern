public class ModernChair extends Chair{
    public void printChair(){
        System.out.println("This is a Modern Chair");
    }
    
}