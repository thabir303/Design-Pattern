public class ArtDecoChair extends Chair{
    public void printChair(){
        System.out.println("This is a ArtDeco Chair");
    }
}