public class ArtDecoCoffeTable extends CoffeTable {
    public void printCoffeTable(){
        System.out.println("This is a Art Deco Coffe Table");
    }
}
