public class ModernSofa extends Sofa {
    public void printSofa(){
        System.out.println("This is a Modern Sofa");
    }
}
