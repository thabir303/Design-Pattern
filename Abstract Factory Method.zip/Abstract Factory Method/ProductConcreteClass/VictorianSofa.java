public class VictorianSofa extends Sofa {
    public void printSofa(){
        System.out.println("This is a Victorian Sofa");
    }
}
