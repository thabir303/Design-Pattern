public class VictorianChair extends Chair{

    public void printChair(){
        System.out.println("This is a Victorian Chair");
    }
}