public class VictorianCoffeTable extends CoffeTable {
    public void printCoffeTable(){
        System.out.println("This is a Victorian CoffeTable");
    }
}
