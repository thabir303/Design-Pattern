public class ArtDecoSofa extends Sofa{
    public void printSofa(){
        System.out.println("This is a Art Deco Sofa");
    }
    
}